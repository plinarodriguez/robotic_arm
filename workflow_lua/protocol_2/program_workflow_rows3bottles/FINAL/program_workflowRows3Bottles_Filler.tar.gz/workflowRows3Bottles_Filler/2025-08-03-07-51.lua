PTP(pHome,75,-1,0)
ActGripper(1,1)
MoveGripper(1,33,75,17,5000,0,0,0,0,0)
loop1 = 0 
while (loop1 < 3) do
-- Bottle 1 
Lin(ptBottleAboveFinal_bottle1,20,-1,0,0)
Lin(ptBottle1,20,-1,0,0)
MoveGripper(1,28,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle1,50,-1,0,0)
Lin(boxbottle_pt3NEW,50,-1,0,0)
Lin(bottlepickUpBOX_pt4NEW,10,-1,0,0)
WaitMs(3000)
Lin(boxbottle_pt3NEW,25,-1,0,0)
Lin(ptBottleAboveFinal_bottle1,20,-1,0,0)
Lin(ptBottle1,20,-1,0,0)
MoveGripper(1,33,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle1,20,-1,0,0)

-- Bottle 2
Lin(ptBottleAboveFinal_bottle2,20,-1,0,0)
Lin(ptBottle2,20,-1,0,0)
MoveGripper(1,28,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle2,50,-1,0,0)
Lin(boxbottle_pt3NEW,50,-1,0,0)
Lin(bottlepickUpBOX_pt4NEW,10,-1,0,0)
WaitMs(3000)
Lin(boxbottle_pt3NEW,25,-1,0,0)
Lin(ptBottleAboveFinal_bottle2,20,-1,0,0)
Lin(ptBottle2,20,-1,0,0)
MoveGripper(1,33,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle2,20,-1,0,0)

-- Bottle 3
Lin(ptBottleAboveFinal_bottle3,20,-1,0,0)
Lin(ptBottle3,20,-1,0,0)
MoveGripper(1,28,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle3,50,-1,0,0)
Lin(boxbottle_pt3NEW,50,-1,0,0)
Lin(bottlepickUpBOX_pt4NEW,10,-1,0,0)
WaitMs(3000)
Lin(boxbottle_pt3NEW,25,-1,0,0)
Lin(ptBottleAboveFinal_bottle3,20,-1,0,0)
Lin(ptBottle3,20,-1,0,0)
MoveGripper(1,33,75,17,5000,0,0,0,0,0)
Lin(ptBottleAboveFinal_bottle3,20,-1,0,0)

loop1 = loop1 + 1
end

PTP(pHome,75,-1,0)
MoveGripper(1,100,75,17,5000,0,0,0,0,0)
ActGripper(1,0)